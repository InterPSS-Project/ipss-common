module SparsePartitionSolve {
}